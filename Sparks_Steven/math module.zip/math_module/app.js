var mathlib = require('./mathlib.js')(); 
console.log(mathlib);
mathlib.add(5,5);
mathlib.multiply(5,5);
mathlib.square(5);
